package com.axitech.service;

public class pdg extends personne {

    public pdg() {
    }

    public pdg(int id, String nom, String prenom, String adresse) {
        super(id, nom, prenom, adresse);
    }
    
    
    
}
