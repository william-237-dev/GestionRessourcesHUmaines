package com.axitech.service;

public class employe extends personne {

    public employe() {
    }

    public employe(int id, String nom, String prenom, String adresse) {
        super(id, nom, prenom, adresse);
    }
    
    
}
