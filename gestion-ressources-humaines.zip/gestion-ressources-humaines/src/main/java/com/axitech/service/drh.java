package com.axitech.service;

public class drh extends personne {

    public drh() {
    }

    public drh(int id, String nom, String prenom, String adresse) {
        super(id, nom, prenom, adresse);
    }
       
    
}
