package com.axitech.service;

import java.sql.Date;

public class conge {
    private String nom;
    private Date date1;
    private Date date2;
    
    public conge() {
    }

    public conge(String nom, Date date1, Date date2) {
        this.nom = nom;
        this.date1 = date1;
        this.date2 = date2;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Date getDate1() {
        return date1;
    }

    public void setDate1(Date date1) {
        this.date1 = date1;
    }

    public Date getDate2() {
        return date2;
    }

    public void setDate2(Date date2) {
        this.date2 = date2;
    }


}
