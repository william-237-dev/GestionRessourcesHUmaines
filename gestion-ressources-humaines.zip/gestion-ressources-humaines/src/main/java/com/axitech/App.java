package com.axitech;

import com.axitech.service.personne;
import com.axitech.service.drh;
import com.axitech.service.pdg;
import com.axitech.service.employe;
import com.axitech.service.tache;
import com.axitech.service.conge;
import com.axitech.service.mission;
import com.axitech.dao.database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        database db = new database();
        Connection connection = db.getConnection();

        if (connection == null) {
            System.out.println("Echec de connexion a la base de donnees !");
            return;
        }

        System.out.println("Connexion reussie !");

        try {
            Scanner scann = new Scanner(System.in);

            String sql = "INSERT INTO personne (id, nom, prenom, adresse) VALUES (?, ?, ?, ?)";
            PreparedStatement pstatement = connection.prepareStatement(sql);

            System.out.println("Veuillez entrer votre nom :");
            String nom = scann.nextLine();

            System.out.println("Veuillez entrer votre prenom :");
            String prenom = scann.nextLine();

            System.out.println("Veuillez entrer votre adresse :");
            String adresse = scann.nextLine();

            int id = 1;
            id = id+1;
            id ++;
            pstatement.setInt(1, id);
            pstatement.setString(2, nom);
            pstatement.setString(3, prenom);
            pstatement.setString(4, adresse);

            int result = pstatement.executeUpdate();
            System.out.println("Nombre de lignes inserees : " + result);

        } catch (Exception e) {
            System.out.println("Erreur : " + e.getMessage());
        }

      
            
        String sql="DELETE FROM personne WHERE nom=?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(2, "TCHANTCHOU");
            ps.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}

